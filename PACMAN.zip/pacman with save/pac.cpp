#include <iostream>
#include <ctime>
#include <windows.h>
#include <string>
#include <conio.h>
#include <fstream>
using namespace std;

enum direction { stop = 0 ,LEFT,RIGHT,UP,DOWN
};
 direction dman;
 int dghost;
 int dghost1;
 int dghost2;
 bool playing= true;
 string f="@";
 string man="P"; 
 string g="G";
 string g1="g";
string g2="R";
int xman,yman,xg,yg,xg1,yg1,xg2,yg2,xf,yf;
bool stop1=false;
 string map[13][20] =  {
	"|","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|",
	"|",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","|",	 	
	"|",".",".",".",".","|",".",".","|","|","|","|","|","|",".",".","|",".",".","|",
	"|",".","|",".",".","|",".",".",".",".",".",".",".","|",".",".","|",".",".","|",
	"|",".","|",".",".","|",".",".","|","|","|","|","|","|",".",".","|",".",".","|",       
	"|",".","|",".",".","|",".",".",".",".",".",".",".",".",".",".","|",".",".","|",	 
	"|",".","|",".",".","|","|","|","|","|","|","|","|","|",".",".","|",".",".","|",				
	"|",".","|",".",".",".",".",".",".",".",".",".",".",".",".",".","|",".",".","|",
	"|",".","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|",".",".","|",						
	"|",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","|",	
	"|",".","|","|","|","|","|",".",".",".",".","|","|","|","|","|","|",".",".","|",											 
	"|",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","|",
	"|","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|","|"};
int score=0;
void load(){
	string input;
	ifstream fin;
			fin.open("savefile.txt");
			if (!fin.is_open()) {
			
					}
/*		for(int i=0 ; i<13 ; i++){
			for(int j=0 ; j<20 ; j++){
				getline(fin , input);
				map[i][j]=input[0];
		}

	}*/
	fin>>score>>xman>>yman>>xg>>yg>>xg1>>yg1>>xg2>>yg2>>xf>>yf;	
	
	fin.close();
	remove("savefile.txt");
			}

void saving(){
	
	
	ofstream file;
		file.open("savefile.txt", ios::app);
	if (!file.is_open()) {
		cout << "Error!!!\n";
		
				}
/*	for(int i=0 ; i<13 ; i++){
		for(int j=0 ; j<20 ; j++){
			file<<map[i][j]<<"\n ";
		}
		file<<endl;
	}*/
	
	file<<score<<" "<<xman<<" "<<yman<<" "<<xg<<" "<<yg<<" "<<xg1<<" "<<yg1<<" "<<xg2<<" "<<yg2<<" "<<xf<<" "<<yf;

			file.close();

}

void pressZ()  {
	
	if (_kbhit())
	{
		switch (_getch())
		{
			case 'z':
				system("cls");
				cout<<"Game saved";
				playing=false;
				saving();
				 
		}
		
	}
}
void show(){
	system("cls");
	
	for(int i=0 ; i<13 ; i++){
		for(int j=0 ; j<20 ; j++){
			cout<<map[i][j];
		}
		cout<<endl;
	}
	cout<<"\n SCORE:"<<score;
	cout<<"\n If you press Z Game saved";
}
void showchars(){
	srand(time(NULL));
	
	xman=(rand() % (11 - 1)) + 1;
	yman=(rand() % (18 -1)) + 1;
	map[xman][yman]=man;
	xg=(rand() % (11 -1)) + 1;
	yg=(rand() % (18 -1)) + 1;
	map[xg][yg]=g;
	xg1=(rand() % (11 - 1)) +1;
	yg1=(rand() % (18 -1)) +1;
	map[xg1][yg1]=g1;
	xg2=(rand() % (11 - 1)) + 1;
	yg2=(rand() % (18 -1)) + 1;
	map[xg2][yg2]=g2;
	xf=(rand() % (11 - 1)) + 1;
	yf=(rand() % (18 -1)) + 1;
	map[xf][yf]=f;
}
void showcharssave(){
		

	map[xman][yman]=man;

	map[xg][yg]=g;

	map[xg1][yg1]=g1;

	map[xg2][yg2]=g2;

	map[xf][yf]=f;
	
	
	
}
void buttons()  {
	
	if (_kbhit())
	{
		switch (_getch())
		{
			case 'a':
				dman = LEFT;
				break;
			case 'd' :
				dman = RIGHT ;
				break;
			case 's' :
				dman = DOWN;
				break;
			case 'w' :
				dman = UP;
				break;
			default:
			 dman= stop;				 
		}
		
	}
}
void moveman(){
	int lx,ly,lx1,ly1;
	lx=xman;
	ly=yman;
	ly1=yman;
	lx1=xman;
		switch(dman){
			case LEFT:
		
				if((map[lx][ly--]!= "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){	
					if(map[lx][ly]=="."){
						score++;
					}
					yman--;
					map[xman][yman]=man;
					map[lx1][ly1]=" ";
					show();
				}
				 if(map[lx][ly]=="G"){

				playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					exit(0); 
				 }				
				if((map[lx][ly]=="g"||map[lx][ly]=="R")){
					
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					exit(0);
					
				}
				if(map[lx][ly]=="|"){
					map[xman][yman]=man;
				}
				if(map[lx][ly]=="@"){
					yman--;
					map[xman][yman]=man;
					map[lx1][ly1]=" ";
					stop1=true;
					show();
					
				}
				
				break;
			case RIGHT:
				if((map[lx][ly++] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){	
					if(map[lx][ly]=="."){
						score++;
					}
				yman++;
				map[xman][yman]=man;
				map[lx1][ly1]=" ";
				show();
				}
				 if(map[lx][ly]=="G"){

				playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					exit(0); 
				 }				
				if((map[lx][ly]=="g"||map[lx][ly]=="R")){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					exit(0);
					
				}
				if(map[lx][ly]=="|"){
					map[xman][yman]=man;
				}
				if(map[lx][ly]=="@"){
					yman++;
					map[xman][yman]=man;
					map[lx1][ly1]=" ";
					stop1=true;
					show();
					
				}

				break;
			case UP:
				
				if((map[lx--][ly] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					if(map[lx][ly]=="."){
						score++;
					}
				xman--;
				map[xman][yman]=man;
				map[lx1][ly1]=" ";
				show();
				}
				 if(map[lx][ly]=="G"){

				playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					exit(0); 
				 }				
				if((map[lx][ly]=="g"||map[lx][ly]=="R")){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					exit(0); 
					
				}
				if(map[lx][ly]=="|"){
					map[xman][yman]=man;
				}
				if(map[lx][ly]=="@"){
					xman--;
					map[xman][yman]=man;
					map[lx1][ly1]=" ";
					stop1=true;
					show();
					
				}	
	
				break;
			case DOWN:
				if((map[lx++][ly] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					if(map[lx][ly]=="."){
						score++;
					}
			 	xman++;
				 map[xman][yman]=man;
				 map[lx1][ly1]=" ";
				 show();
				 }
				 if(map[lx][ly]=="G"){

				playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					exit(0); 
				 }
				
				if((map[lx][ly]=="g"||map[lx][ly]=="R")){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					exit(0); 
					
				}
				if(map[lx][ly]=="|"){
					map[xman][yman]=man;
				}
				if(map[lx][ly]=="@"){
					xman++;
					map[xman][yman]=man;
					map[lx1][ly1]=" ";
					stop1=true;
					show();
					
				}				
				
				break;
			case stop:
				break;
	
}

dman = stop;
		
}

string save=" ";
int makeGhostMove(){
	int lx,ly,lx1,ly1;
	bool moving=false;
	lx=xg;
	ly=yg;
	lx1=xg;
	ly1=yg;
	
	string save2;
	save2=save;
	srand(time(NULL));
	dghost=(rand() % (4 - 1)) + 1;

			switch(dghost){
			case 1:
					
				if((map[lx][ly--] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg][yg]=g;
				}
				if(map[lx][ly] == "P"){

					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					yg--;
					map[xg][yg]=g;
					map[lx1][ly1]=save2;
					show();
				}
	

				break;
			case 2:
				if((map[lx][ly++] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg][yg]=g;
				}
				if(map[lx][ly] == "P"){

					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					yg++;
					map[xg][yg]=g;
					map[lx1][ly1]=save2;
					show();
				}
	

				break;

			
			case 3:
				if((map[lx--][ly] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg][yg]=g;
				}
				if(map[lx][ly] == "P"){

					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					xg--;
					map[xg][yg]=g;
					map[lx1][ly1]=save2;
					show();
				}
	

				break;
			case 4:
				if((map[lx++][ly] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg][yg]=g;
				}
				if(map[lx][ly] == "P"){

					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					xg++;
					map[xg][yg]=g;
					map[lx1][ly1]=save2;
					show();
				}
	

				break;

				
	
	
}

	}
string save1=" ";
int makeGhostMove1(){
	int lx,ly,lx1,ly1;
	bool moving=false;
	lx=xg1;
	ly=yg1;
	lx1=xg1;
	ly1=yg1;
	
	string save2;
	save2=save1;
	srand(time(NULL));
	dghost1=(rand() % (4 - 1)) + 1;

			switch(dghost1){
			case 3:
					
				if((map[lx][ly--] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save1=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg1][yg1]=g1;
				}
				if(map[lx][ly] == "P"){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					yg1--;
					map[xg1][yg1]=g1;
					map[lx1][ly1]=save2;
					show();
				}
	

				break;
			case 4:
				if((map[lx][ly++] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save1=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg1][yg1]=g1;
				}
				if(map[lx][ly] == "P"){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					yg1++;
					map[xg1][yg1]=g1;
					map[lx1][ly1]=save2;
					show();
				}
	

				break;

			
			case 1:
				if((map[lx--][ly] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save1=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg1][yg1]=g1;
				}
				if(map[lx][ly] == "P"){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					xg1--;
					map[xg1][yg1]=g1;
					map[lx1][ly1]=save2;
					show();
				}
	

				break;
			case 2:
				if((map[lx++][ly] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save1=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg1][yg1]=g1;
				}
				if(map[lx][ly] == "P"){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					xg1++;
					map[xg1][yg1]=g1;
					map[lx1][ly1]=save2;
					show();
				}
	

				break;

				
	
	
}

	}
	string save2=" ";
int makeGhostMove2(){
	int lx,ly,lx1,ly1;
	bool moving=false;
	lx=xg2;
	ly=yg2;
	lx1=xg2;
	ly1=yg2;
	
	string save1;
	save1=save2;
	srand(time(NULL));
	dghost2=(rand() % (4 - 1)) + 1;

			switch(dghost2){
			case 4:
					
				if((map[lx][ly--] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save2=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg2][yg2]=g2;
				}
				if(map[lx][ly] == "P"){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					yg2--;
					map[xg2][yg2]=g2;
					map[lx1][ly1]=save1;
					show();
				}
	

				break;
			case 3:
				if((map[lx][ly++] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save2=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg2][yg2]=g2;
				}
				if(map[lx][ly] == "P"){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					yg2++;
					map[xg2][yg2]=g2;
					map[lx1][ly1]=save1;
					show();
				}
	

				break;

			
			case 2:
				if((map[lx--][ly] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save2=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg2][yg2]=g2;
				}
				if(map[lx][ly] == "P"){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					xg2--;
					map[xg2][yg2]=g2;
					map[lx1][ly1]=save1;
					show();
				}
	

				break;
			case 1:
				if((map[lx++][ly] != "|")&&(map[lx][ly]=="."||map[lx][ly]==" ")){
					
					save2=map[lx][ly];
					
					moving=true;
				}
				if(map[lx][ly] == "|"){
					map[xg2][yg2]=g2;
				}
				if(map[lx][ly] == "P"){
					playing = false;
					system("cls");
					cout<<"YOU LOSE"<<"\n SCORE :"<<score;
					return 0; 
				}
				if(moving){
					xg2++;
					map[xg2][yg2]=g2;
					map[lx1][ly1]=save1;
					show();
				}
	

				break;

				
	
	
}

	}


int checkwin(){
	if(score==131){
		playing=false;
		system("cls");
		cout<<"*******YOU WIN*******";
		return 0;
	}
}

int main(){
	
	cout<<"Please choose 1 or 2 then press Enter "<<"\n 1-Start a new Game"<<"\n 2-Resume the saved Game";
	
	int a;
	cin>>a;
	if(a==2){
	  load();

    showcharssave();				
	show();
	while(playing){
		makeGhostMove();
		makeGhostMove1();
		makeGhostMove2();
		buttons();
		moveman();	
		pressZ();
		checkwin();
		}
		
	}

		if(a==1){
			showchars();
		 show();
	while(playing){
		makeGhostMove();
		makeGhostMove1();
		makeGhostMove2();
		buttons();	
		pressZ();
		moveman();
		checkwin();
		}
}}
